# Contributors

Everyone who helped build UE4SS C++ BYPASS.

- KintaroModding: creator and maintainer

Your name goes here with your first merged contribution: code, a re-pin for a new
game build, or a bug report that led to a fix. See CONTRIBUTING.md.
