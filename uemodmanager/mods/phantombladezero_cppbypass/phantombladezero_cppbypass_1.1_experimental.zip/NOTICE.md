# Copyright and additional terms

UE4SS C++ BYPASS
Copyright (C) 2026 KintaroModding and the contributors listed in CONTRIBUTORS.md

This program is free software: you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation, version 3 (see LICENSE), with the additional terms below.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

## Additional terms under section 7 of the GPL

These terms apply to this program and to every work based on it.

1. Credit (section 7b). Keep this file and CONTRIBUTORS.md with the source code.
   Where a work based on this program shows its legal notices, such as a log
   banner, a mod page or a README, keep showing the line "Based on UE4SS C++
   BYPASS by KintaroModding and contributors" with the address
   https://github.com/KintaroModding/phantombladezero_cppbypass.

2. Marked as different (section 7c). A modified version must not claim to be the
   original or an official release. Give it a name of its own (see term 3), and
   state in its legal notices that it is a modified version.

3. Names (section 7e). The GPL grants no rights under trademark law to the names
   "UE4SS C++ BYPASS" and "KintaroModding". You may use them only to state
   truthfully where your work comes from.

## Libraries

This program includes MinHook 1.3.4 (Copyright (C) 2009-2017 Tsuda Kageyu and
contributors, with Hacker Disassembler Engine code by Vyacheslav Patkov) under a
BSD-style license, and a small pinned subset of the UE4SS SDK headers (Copyright
(C) 2022 Narknon and the UE4SS contributors) under the MIT license. Both licenses
are GPL-compatible. The only adaptation of the UE4SS headers avoids unused GUI
dependencies without changing class fields, virtual slots or function types
(see tools/vendor/ue4ss-sdk/PROVENANCE.txt).

Their license texts are in the source package under
tools/vendor/minhook-1.3.4/LICENSE.txt and tools/vendor/ue4ss-sdk/LICENSE, and in
the binary package as MINHOOK-LICENSE.txt and UE4SS-SDK-LICENSE.txt. The binary
links to the player's existing UE4SS.dll and does not redistribute it.
