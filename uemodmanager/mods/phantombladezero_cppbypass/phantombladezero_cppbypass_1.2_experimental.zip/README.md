# UE4SS C++ BYPASS

An independent UE4SS C++ mod by Kintaro. Experimental version 1.2.

Allows modified contents for the 218 listed `project/` scripts and additional
project JavaScript/JSON modules supplied by mods. This lets compatible script
pak mods run after the 2026-11-04 update, including mods that add new modules.

**Version 1.2 adds UE4SS v4.0.0. It passes the standalone native tests and was
confirmed in game on UE4SS v4.0.0 with an existing-script pak replacement
(Animation Cancel). Version 1.0 was confirmed in game the same way on UE4SS build
1195. Its additional-module support still needs an in-game test. Pinned to one game
build and two verified UE4SS builds.**

## Supported versions

- Phantom Blade Zero Steam build 26367565, CL-302256_JKS-17280.
- PBZ.exe SHA-256: `4415933ce33476f14c837abb61a1b60af8b78cd81783896501913a7aac69e423`.
- UE4SS v4.0.0, commit `30afe5fff94a94c2313e220b2002059a080da9a0`, `UE4SS.dll` SHA-256
  `3843d81a8280096b0de3c750eebf15507e374c250dc551cbf07e7be7acc1e2ba` (the official release zip).
- UE4SS build 1195 (`v3.0.1-1195-g1ceefac8`), commit `1ceefac8b8c286f0fb3eb62b4aae075ff81df0bd`, `UE4SS.dll`
  SHA-256 `e1fb9a7e1d868afef6a091c2012e711c3ec47f05d100ba37f9631a4f75f31df2`.
- Windows x64, release MSVC runtime (`/MD`).

The pinned UE4SS SDK headers are byte-identical in both UE4SS builds, and all 17
UE4SS functions this mod imports exist in both, so one DLL serves both. The
log names the UE4SS build it found.

The mod checks both executable files by SHA-256 and checks the native validators
and lookup code in memory before creating hooks. An unsupported build is left
unpatched. Future game or UE4SS updates require a reviewed compatibility update.

## Install and first game test

1. Close the game. Use a supported UE4SS build and its working PBZ configuration
   (UE4SS includes a Phantom Blade Zero configuration from the release after v4.0.0;
   for v4.0.0 itself, add the configuration files yourself).
2. Copy the package's `ue4ss/Mods/phantombladezero_cppbypass` folder into the
   existing `ue4ss/Mods` folder beside the game's platform executable.
3. Keep PBZModLoader out of this test. Coexistence has not been tested.
4. Test with one script pak mod that has been updated against this game build.
5. Start the game. Inspect
   `ue4ss/Mods/phantombladezero_cppbypass/compatibility.log`.
6. Look for `Verified UE4SS ...`, `Both validators hooked` and `Allowed listed project script` or
   `Allowed additional project script` entries for the mod's scripts. Confirm that menu labels display normally and the mod's
   gameplay change works. A hook log alone does not establish gameplay success.

To remove it, close the game and remove only this mod's folder. A full restart
is required after enabling, disabling or replacing this mod. Runtime unload
disables the hooks but retains trampoline memory and pins the DLL until exit so
in-flight callbacks cannot jump into freed code. Hot reload is unsupported.

## Scope

Both the byte-content and text-content validators are hooked. Existing records
in the verified 241-entry table retain the project-only exception. For a module
absent from that table, the game's own path normalizer must produce a canonical
`project/` path ending in `.js` or `.json`. The returned string is released with
the matching game allocator. Both additional helper functions are pinned and
checked in memory before installation. Engine scripts, paths outside the project
script tree and malformed paths use the original validators with unchanged
arguments and return values. Each accepted script is logged once per process.

Mods can supply new project modules through their normal pak files and import
them from their scripts. This mod adds no bootstrap or TypeScript compiler.
It does not change the separate InstallVerify feature. It cannot repair old mod
logic or merge two pak mods that replace the same script. Mods still need to be
checked against current game scripts.

Allowing a new module cannot restore a file removed by a game update. A mod whose
old startup script imports removed game files still needs updating by its author.

## Build

The source package includes the small pinned UE4SS header subset, its license,
an import-library definition and MinHook 1.3.4 source. No PBZModLoader code or game
code is included. The mod's own source is under the GNU General Public License,
version 3 (see LICENSE and NOTICE.md); the bundled libraries keep their own
GPL-compatible licenses.

The local build uses a portable MSVC/Windows SDK folder named `msvc` at the project
root. It was obtained with the
[portable MSVC downloader](https://gist.github.com/mmozeiko/7f3162ec2988e81e56d5c4e22cde9977),
using `--vs 2022` after the user's explicit license authorization. That downloader
is a local development tool and is excluded from the source package.

From the project root:

```powershell
python tools/build.py
```

The script uses compiler 14.44.35207 and Windows SDK 10.0.26100.0 in this local
installation. It changes environment variables only for child processes, builds
the DLL with warnings treated as errors, then compiles and runs the native hook
test. Output goes into `dist/`; build files stay in `build/`.

The native test exercises the actual production adapters through MinHook with
fixture validators and a stand-in normalizer/allocator. It verifies existing and
additional project-script acceptance, engine/outside path forwarding, malformed
normalized strings, allocation cleanup, original arguments/results, table bounds
and hook removal. The actual game helper ABI still requires an in-game test.

Private reverse-engineering evidence and tools stay under `research/` and
`tools/`. They are not needed by players and are excluded from the source package.

## Credits

- UE4SS contributors: https://github.com/UE4SS-RE/RE-UE4SS
- Tsuda Kageyu and contributors, MinHook: https://github.com/TsudaKageyu/minhook
- PBZModLoader supplied as a reference by the user demonstrated a folder-scoped
  compatibility approach. This project implements its own table-scoped behavior;
  it neither includes nor requires PBZModLoader.

## Contributing

Contributions are welcome: see [CONTRIBUTING.md](CONTRIBUTING.md). Everyone who
contributes is named in [CONTRIBUTORS.md](CONTRIBUTORS.md).

## License

GNU General Public License, version 3 ([LICENSE](LICENSE)), with additional terms
in [NOTICE.md](NOTICE.md) under section 7: a modified version keeps the credit to
the original and its contributors, is marked as a modified version, and gains no
right to the names "UE4SS C++ BYPASS" and "KintaroModding". The bundled
libraries (MinHook, the pinned UE4SS SDK header subset) keep their own
GPL-compatible licenses.
