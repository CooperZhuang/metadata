# UE4SS C++ BYPASS

An independent UE4SS C++ mod by Kintaro. Experimental version 1.0.

Allows modified contents for the 218 `project/` scripts already listed in Phantom
Blade Zero's embedded script validation table. This is intended to let compatible
JavaScript pak mods run again after the 2026-11-04 update.

**Compiled and tested in a standalone native harness, and confirmed in game on the
supported build: the game starts and compatible script pak mods load. Still
experimental and pinned to one game and UE4SS build.**

## Supported versions

- Phantom Blade Zero Steam build 26367565, CL-302256_JKS-17280.
- PBZ.exe SHA-256: `4415933ce33476f14c837abb61a1b60af8b78cd81783896501913a7aac69e423`.
- UE4SS build 1195, commit `1ceefac8b8c286f0fb3eb62b4aae075ff81df0bd`.
- Windows x64, release MSVC runtime (`/MD`).

The mod checks both executable files by SHA-256 and checks the native validators
and lookup code in memory before creating hooks. An unsupported build is left
unpatched. Future game or UE4SS updates require a reviewed compatibility update.

## Install and first game test

1. Close the game. Use the supported UE4SS build and its working PBZ configuration.
2. Copy the package's `ue4ss/Mods/phantombladezero_cppbypass` folder into the
   existing `ue4ss/Mods` folder beside the game's platform executable.
3. Keep PBZModLoader out of this test. Coexistence has not been tested.
4. Test with one script pak mod that has been updated against this game build.
5. Start the game. Inspect
   `ue4ss/Mods/phantombladezero_cppbypass/compatibility.log`.
6. Look for `Both validators hooked` and an `Allowed listed project script` entry
   for the mod's script. Confirm that menu labels display normally and the mod's
   gameplay change works. A hook log alone does not establish gameplay success.

This development session has not installed the DLL or changed game files.

To remove it, close the game and remove only this mod's folder. A full restart
is required after enabling, disabling or replacing this mod. Runtime unload
disables the hooks but retains trampoline memory and pins the DLL until exit so
in-flight callbacks cannot jump into freed code. Hot reload is unsupported.

## Scope

Both the byte-content and text-content validators are hooked. The game's own
path normalizer and table lookup decide which entry a requested module names.
Only a correctly aligned record in the verified 241-entry table, whose canonical
path is a `project/` JavaScript or JSON file, receives the compatibility exception.
Other entries and unknown paths use the original validators with unchanged
arguments and return values. Each accepted script is logged once per process.

This permits changed contents for known game scripts. It does not load arbitrary
new modules, add a bootstrap, add TypeScript support or enable unrestricted eval.
It does not change the separate InstallVerify feature. It cannot repair old mod
logic or merge two pak mods that replace the same script. Mods still need to be
checked against current game scripts.

## Build

The source package includes the small pinned UE4SS header subset, its license,
an import-library definition and MinHook 1.3.4 source. No PBZModLoader code or game
code is included. The mod's own source is under the GNU General Public License,
version 3 (see LICENSE and NOTICE.md); the bundled libraries keep their own
GPL-compatible licenses.

The local build uses a portable MSVC/Windows SDK folder named `msvc` at the project
root. It was obtained with the
[portable MSVC downloader](https://gist.github.com/mmozeiko/7f3162ec2988e81e56d5c4e22cde9977),
using `--vs 2022` after the user's explicit license authorization. That downloader
is a local development tool and is excluded from the source package.

From the project root:

```powershell
python tools/build.py
```

The script uses compiler 14.44.35207 and Windows SDK 10.0.26100.0 in this local
installation. It changes environment variables only for child processes, builds
the DLL with warnings treated as errors, then compiles and runs the native hook
test. Output goes into `dist/`; build files stay in `build/`.

The native test exercises the actual production adapters through MinHook with
fixture validators. It verifies project-script acceptance, engine and unknown
path forwarding, preservation of arguments and original true/false results,
table bounds and hook removal. It does not run the game.

Private reverse-engineering evidence and tools stay under `research/` and
`tools/`. They are not needed by players and are excluded from the source package.

## Credits

- UE4SS contributors: https://github.com/UE4SS-RE/RE-UE4SS
- Tsuda Kageyu and contributors, MinHook: https://github.com/TsudaKageyu/minhook
- PBZModLoader supplied as a reference by the user demonstrated a folder-scoped
  compatibility approach. This project implements its own table-scoped behavior;
  it neither includes nor requires PBZModLoader.

## Contributing

Contributions are welcome: see [CONTRIBUTING.md](CONTRIBUTING.md). Everyone who
contributes is named in [CONTRIBUTORS.md](CONTRIBUTORS.md).

## License

GNU General Public License, version 3 ([LICENSE](LICENSE)), with additional terms
in [NOTICE.md](NOTICE.md) under section 7: a modified version keeps the credit to
the original and its contributors, is marked as a modified version, and gains no
right to the names "UE4SS C++ BYPASS" and "KintaroModding". The bundled
libraries (MinHook, the pinned UE4SS SDK header subset) keep their own
GPL-compatible licenses.
